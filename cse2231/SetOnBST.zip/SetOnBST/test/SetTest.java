import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;

/**
 * JUnit test fixture for {@code Set<String>}'s constructor and kernel methods.
 *
 * @author Qinuo Shi & Yiming Cheng
 *
 */
public abstract class SetTest {

    /**
     * Invokes the appropriate {@code Set} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new set
     * @ensures constructorTest = {}
     */
    protected abstract Set<String> constructorTest();

    /**
     * Invokes the appropriate {@code Set} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new set
     * @ensures constructorRef = {}
     */
    protected abstract Set<String> constructorRef();

    /**
     * Creates and returns a {@code Set<String>} of the implementation under
     * test type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsTest = [entries in args]
     */
    private Set<String> createFromArgsTest(String... args) {
        Set<String> set = this.constructorTest();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    /**
     * Creates and returns a {@code Set<String>} of the reference implementation
     * type with the given entries.
     *
     * @param args
     *            the entries for the set
     * @return the constructed set
     * @requires [every entry in args is unique]
     * @ensures createFromArgsRef = [entries in args]
     */
    private Set<String> createFromArgsRef(String... args) {
        Set<String> set = this.constructorRef();
        for (String s : args) {
            assert !set.contains(
                    s) : "Violation of: every entry in args is unique";
            set.add(s);
        }
        return set;
    }

    // TODO - add test cases for constructor, add, remove, removeAny, contains, and size

    /*
     * Test for constructors
     */
    @Test
    public final void testConstructor() {
        Set<String> s = this.constructorTest();
        Set<String> sexpected = this.constructorRef();

        assertEquals(sexpected, s);
    }

    /*
     * Test for kernel methods
     */

    /*
     * Test for add
     */
    @Test
    public final void testEmpty() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sexpected = this.createFromArgsRef("a");

        s.add("a");
        assertEquals(sexpected, s);
    }

    @Test
    public final void testNonEmpty1() {
        Set<String> s = this.createFromArgsTest("a", "b");
        Set<String> sexpected = this.createFromArgsRef("a", "b", "c");

        s.add("c");
        assertEquals(sexpected, s);
    }

    @Test
    public final void testNonEmpty2() {
        Set<String> s = this.createFromArgsTest("a", "b", "c", "d");
        Set<String> sexpected = this.createFromArgsRef("a", "b", "c", "d", "e");

        s.add("e");
        assertEquals(sexpected, s);
    }

    @Test
    public final void testNonEmpty3() {
        Set<String> s = this.createFromArgsTest("Z", "Y", "W");
        Set<String> sexpected = this.createFromArgsRef("Z", "Y", "W", "X");

        s.add("X");
        assertEquals(sexpected, s);
    }

    @Test
    public final void testNonEmpty4() {
        Set<String> s = this.createFromArgsTest("d", "c", "a", "b", "e", "f",
                "g");
        Set<String> sexpected = this.createFromArgsRef("d", "c", "a", "b", "e",
                "f", "g", "s");

        s.add("s");
        assertEquals(sexpected, s);
    }

    /*
     * Test for remove
     */
    @Test
    public final void testRemoveEmpty() {
        Set<String> s = this.createFromArgsTest("a");
        Set<String> sexpected = this.createFromArgsRef();
        String rexpected = "a";

        String r = s.remove("a");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty1() {
        Set<String> s = this.createFromArgsTest("f", "a", "b", "n", "g");
        Set<String> sexpected = this.createFromArgsRef("f", "a", "b", "n");
        String rexpected = "g";

        String r = s.remove("g");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty2() {
        Set<String> s = this.createFromArgsTest("f", "a", "b", "n", "g");
        Set<String> sexpected = this.createFromArgsRef("f", "a", "n", "g");
        String rexpected = "b";

        String r = s.remove("b");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty3() {
        Set<String> s = this.createFromArgsTest("c", "b", "a");
        Set<String> sexpected = this.createFromArgsRef("c", "b");
        String rexpected = "a";

        String r = s.remove("a");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty4() {
        Set<String> s = this.createFromArgsTest("w", "y", "z");
        Set<String> sexpected = this.createFromArgsRef("y", "z");
        String rexpected = "w";

        String r = s.remove("w");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty5() {
        Set<String> s = this.createFromArgsTest("m", "g", "u", "e", "f", "t");
        Set<String> sexpected = this.createFromArgsRef("m", "g", "e", "f", "t");
        String rexpected = "u";

        String r = s.remove("u");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    @Test
    public final void testRemoveNonEmpty6() {
        Set<String> s = this.createFromArgsTest("t", "s", "r", "q");
        Set<String> sexpected = this.createFromArgsRef("s", "r", "q");
        String rexpected = "t";

        String r = s.remove("t");
        assertEquals(sexpected, s);
        assertEquals(rexpected, r);
    }

    /*
     * Test for removeAny
     */
    @Test
    public void testRemoveAnyFromConstructorWithElements1() {
        Set<String> s = this.createFromArgsTest("a");
        Set<String> sExpected = this.createFromArgsRef("a");

        String sremoveAny = s.removeAny();
        String sExpectedremoveAny = sExpected.remove(sremoveAny);
        assertEquals(sExpectedremoveAny, sremoveAny);
        assertEquals(sExpected, s);
    }

    @Test
    public void testRemoveAnyFromConstructorWithElements2() {
        Set<String> s = this.createFromArgsTest("a", "b", "c", "d");
        Set<String> sExpected = this.createFromArgsRef("a", "b", "c", "d");

        String sremoveAny = s.removeAny();
        String sExpectedremoveAny = sExpected.remove(sremoveAny);
        assertEquals(sExpectedremoveAny, sremoveAny);
        assertEquals(sExpected, s);
    }

    /*
     * Test for contain
     */
    @Test
    public final void testContainsEmpty() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sexpected = this.createFromArgsRef();

        assertEquals(false, s.contains("a"));
        assertEquals(sexpected, s);
    }

    @Test
    public final void testTrue() {
        Set<String> s = this.createFromArgsTest("a", "b", "c", "d");
        Set<String> sexpected = this.createFromArgsRef("a", "b", "c", "d");

        assertEquals(true, s.contains("b"));
        assertEquals(sexpected, s);
    }

    @Test
    public final void testFalse() {
        Set<String> s = this.createFromArgsTest("a", "b", "c", "d");
        Set<String> sexpected = this.createFromArgsRef("a", "b", "c", "d");

        assertEquals(false, s.contains("e"));
        assertEquals(sexpected, s);
    }

    /*
     * Test for size
     */
    @Test
    public final void testSizeEmpty() {
        Set<String> s = this.createFromArgsTest();
        Set<String> sexpected = this.createFromArgsRef();

        assertEquals(0, s.size());
        assertEquals(sexpected, s);
    }

    @Test
    public final void testSizeOne() {
        Set<String> s = this.createFromArgsTest("a");
        Set<String> sexpected = this.createFromArgsRef("a");

        assertEquals(1, s.size());
        assertEquals(sexpected, s);
    }

    @Test
    public final void testSizeTwo() {
        Set<String> s = this.createFromArgsTest("a", "b", "c", "d");
        Set<String> sexpected = this.createFromArgsRef("a", "b", "c", "d");

        assertEquals(4, s.size());
        assertEquals(sexpected, s);
    }

}
