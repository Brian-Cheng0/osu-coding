import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Put your name here
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    // TODO - add test cases for four constructors, multiplyBy10, divideBy10, isZero

    /**
     * Test non-element.
     */
    @Test
    public final void testNonConstructor() {
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        assertEquals(n, nExpected);
    }

    /**
     * Test one digit.
     */
    @Test
    public final void testConstructorOne() {
        NaturalNumber n = this.constructorTest(9);
        NaturalNumber nExpected = this.constructorRef(9);
        assertEquals(n, nExpected);
    }

    /**
     * Test many digits.
     */
    @Test
    public final void testStringConstructorForMany() {
        NaturalNumber n = this.constructorTest("12312312");
        NaturalNumber nExpected = this.constructorRef("12312312");
        assertEquals(n, nExpected);
    }

    /**
     * Test cases for multiplyBy10
     */

    @Test
    public final void testMultiplyBy10Ints() {
        /*
         * Initialize the variables
         */
        int first = 2;
        int ans = 20;
        NaturalNumber n = this.constructorTest(first);
        NaturalNumber nExpected = this.constructorRef(ans);
        n.multiplyBy10(0);
        assertEquals(nExpected, n);
    }

    @Test
    public final void testMultiplyBy10UsingString() {
        /*
         * Initialize the variables
         */
        String original = "4564";
        String changed = "45640";
        NaturalNumber n = this.constructorTest(original);
        NaturalNumber nExpected = this.constructorRef(changed);
        n.multiplyBy10(0);
        assertEquals(nExpected, n);
    }

    @Test
    public final void testMultiplyBy10MaxInts() {
        /*
         * Initialize variables
         */
        int first = Integer.MAX_VALUE;
        NaturalNumber n = this.constructorTest(first);
        NaturalNumber nExpected = this.constructorRef(first);
        nExpected.multiplyBy10(0);
        n.multiplyBy10(0);
        assertEquals(nExpected, n);
    }

    @Test
    public final void testMultiplyBy10UsingZero() {
        /*
         * Initialize variables
         */
        int original = 0;
        int changed = 0;
        NaturalNumber n = this.constructorTest(original);
        NaturalNumber nExpected = this.constructorRef(changed);
        nExpected.multiplyBy10(0);
        assertEquals(nExpected, n);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on50() {
        NaturalNumber nn = this.constructorTest(50);
        NaturalNumber nnExpected = this.constructorRef(5);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 0);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on12300() {
        NaturalNumber nn = this.constructorTest(12300);
        NaturalNumber nnExpected = this.constructorRef(1230);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 0);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on63() {
        NaturalNumber nn = this.constructorTest(63);
        NaturalNumber nnExpected = this.constructorRef(6);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 3);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on9() {
        NaturalNumber nn = this.constructorTest(9);
        NaturalNumber nnExpected = this.constructorRef(0);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 9);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on19InString() {
        NaturalNumber nn = this.constructorTest("19");
        NaturalNumber nnExpected = this.constructorRef(1);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 9);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on19InNN() {
        NaturalNumber NN = this.constructorTest(19);
        NaturalNumber nn = this.constructorTest(NN);
        NaturalNumber nnExpected = this.constructorRef(1);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 9);
    }

    /**
     * Test for divideBy10.
     */
    @Test
    public final void testDivideBy10on0InNN() {
        NaturalNumber NN = this.constructorTest(0);
        NaturalNumber nn = this.constructorTest(NN);
        NaturalNumber nnExpected = this.constructorRef(0);
        int r = nn.divideBy10();
        assertEquals(nn, nnExpected);
        assertTrue(r == 0);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroTrueNoElement() {
        NaturalNumber nn = this.constructorTest();
        boolean b = nn.isZero();
        assertEquals(b, true);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroTrueWithInt() {
        NaturalNumber nn = this.constructorTest(0);
        boolean b = nn.isZero();
        assertEquals(b, true);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroTrueWithString() {
        NaturalNumber nn = this.constructorTest("0");
        boolean b = nn.isZero();
        assertEquals(b, true);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroTrueWithNN() {
        NaturalNumber nnExpect = this.constructorTest(0);
        NaturalNumber nn = this.constructorTest(nnExpect);
        boolean b = nn.isZero();
        assertEquals(b, true);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroFalseWithInt() {
        NaturalNumber nn = this.constructorTest(1);
        boolean b = nn.isZero();
        assertEquals(b, false);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroFalseWithString() {
        NaturalNumber nn = this.constructorTest("1");
        boolean b = nn.isZero();
        assertEquals(b, false);
    }

    /**
     * Test for isZero.
     */
    @Test
    public final void testIsZeroFalseWithNN() {
        NaturalNumber NN = this.constructorTest(1);
        NaturalNumber nn = this.constructorTest(NN);
        boolean b = nn.isZero();
        assertEquals(b, false);
    }

}
