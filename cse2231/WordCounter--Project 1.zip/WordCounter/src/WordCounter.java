import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Program to take a file of text, count the times of every word, and make a
 * page displaying each word and number of words that appear.
 *
 * @author Yiming Cheng
 *
 */
public final class WordCounter {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private WordCounter() {
        // no code needed here
    }

    /**
     * In order to sort the terms in an alphabetic order.
     */
    private static class stringList implements Comparator<String> {
        @Override
        public int compare(String o1, String o2) {
            return o1.toLowerCase().compareTo(o2.toLowerCase());
        }

    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} which are got from the word
     * @param position
     *            the starting position of index
     * @param separators
     *            the certain punctuation which is from the list.
     * @return the first word or separator string in the index position
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        int endPos = -1;
        String word = "";
        int i = position;
        /*
         * find the corresponding substrings by separator
         */
        while (i < text.length()) {
            if (separators.contains(text.charAt(i)) && endPos == -1) {
                endPos = i;
            }
            if (endPos == -1) {
                word = text.substring(position, text.length());
            } else if (endPos == position) {
                word = text.substring(position, position + 1);
            } else {
                word = text.substring(position, endPos);
            }
            i++;
        }

        return word;

    }

    /**
     * Outputs the main page index.html. Expected elements from this method:
     *
     * @param map
     *            the map of terms and their occurrences
     * @param out
     *            the output stream
     * @param title
     *            the string of the file name
     * @param titlelist
     *            the queue of unique words
     * @updates out.content
     * @requires out.is_open
     * @ensures out.content = #out.content * [the HTML tags]
     */
    private static void outputhtml(Map<String, Integer> map, SimpleWriter out,
            String title, Queue<String> titlelist) {
        assert out.isOpen() : "Violation of: out.is_open";
        //print the whole formats for the page.
        out.print("<html>\r\n" + "<head>\r\n" + "<title> " + title
                + "</title>\r\n" + "\r\n" + "</head>\r\n" + "\r\n");

        out.print(
                "<body>\r\n" + "<h2>" + title + "</h2>\r\n" + "<hr>" + "\r\n");

        out.print("<table border= \"1\"> \r\n");
        out.print("<tbody>\r\n");

        out.print("<tr>\r\n");
        out.print("<th>" + "Words" + "</th>\r\n");
        out.print("<th>" + "Counts" + "</th>\r\n");
        out.print("</tr>\r\n");
        int counter = titlelist.length();
        int i = 0;
        while (i < counter) {
            String word = titlelist.dequeue();
            out.print("<tr>\r\n");
            out.print("<td>" + word + "</td>\r\n");
            out.print("<td>" + map.value(word) + "</td>\r\n");
            out.print("</tr>\r\n");
            i++;
        }

        out.print("</tbody>\r\n" + "</table>\r\n" + "</body>\r\n" + "</html>");
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strList
     *            the {@code Set} to be replaced
     * @replaces strSet
     * @ensures strSet = entries(str)
     */
    private static void generateElements(String str, Set<Character> strList) {
        assert str != null : "Violations of: str is not null";
        assert strList != null : "Violation of: strSet is not null";
        int i = 0;
        while (i < str.length()) {
            char c = str.charAt(i);
            if (!strList.contains(c)) {
                strList.add(c);
            }
            i++;
        }
    }

    /**
     * process the data in the list and map into the new queue.
     *
     * @param list
     *            the original list that need to be move
     * @param map
     *            the map that store the words and the times that the words
     *            would appear
     * @return the queue that would be displayed.
     */
    private static Queue<String> processItems(Queue<String> list,
            Map<String, Integer> map) {
        int iteratorNum = list.length();

        Queue<String> temp = list.newInstance();
        for (int i = 0; i < iteratorNum; i++) {
            String word = list.dequeue();
            temp.enqueue(word);
            list.enqueue(word);
        }
        int a = 0;
        while (a < iteratorNum) {
            String word = list.dequeue();
            int number = 1;
            if (map.hasKey(word)) {
                int count = map.value(word);
                map.replaceValue(word, count + 1);
            } else {
                map.add(word, number);
            }
            a++;
        }

        Set<String> words = new Set1L<>();
        for (String x : temp) {
            if (!words.contains(x)) {
                words.add(x);
            }
        }
        for (String x : words) {
            list.enqueue(x);
        }

        return list;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        //ask the users about the file.

        out.print("Enter file that will be used to obtain the words: ");
        String text = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(text);
        //ask the users about the name of the html page.
        out.print("Enter the name of a of the html page to write to: ");
        String htmlpage = in.nextLine();
        SimpleWriter outputhtml = new SimpleWriter1L(htmlpage);

        Queue<String> list = new Queue1L<>();
        Map<String, Integer> map = new Map1L<>();
        //separate the string into the different parts.
        final String separatorStr = " \t, .-";
        Set<Character> separatorList = new Set1L<>();
        generateElements(separatorStr, separatorList);
        while (!inFile.atEOS()) {
            String line = inFile.nextLine();
            int i = 0;
            while (i < line.length()) {
                String word = nextWordOrSeparator(line, i, separatorList);
                boolean isWord = true;
                for (int j = 0; j < word.length(); j++) {
                    char c = word.charAt(j);
                    if (separatorList.contains(c)) {
                        isWord = false;
                    }
                }
                if (isWord) {
                    list.enqueue(word);
                }
                i += word.length();
            }
        }

        // make the right order
        Comparator<String> cs = new stringList();

        Queue<String> temp = list.newInstance();
        temp = processItems(list, map);
        temp.sort(cs);

        String title = "Words Counted in " + text;
        outputhtml(map, outputhtml, title, temp);

        inFile.close();
        out.close();
        in.close();
    }

}