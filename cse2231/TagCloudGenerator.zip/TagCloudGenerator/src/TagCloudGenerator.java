import java.util.Comparator;

import components.map.Map;
import components.map.Map.Pair;
import components.map.Map1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.sortingmachine.SortingMachine;
import components.sortingmachine.SortingMachine1L;
import components.utilities.Reporter;

/**
 * Read txt and find the amount words that appear most frequently. The amount is
 * an integer entered by the user.
 *
 * @author Qinuo Shi & Yiming Cheng
 *
 */
public final class TagCloudGenerator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private TagCloudGenerator() {
    }

    /**
     * there separator are used in countingWords method.
     */
    public static final String Separator = "\\ \t\n\r,-.!?[]';:/()@&~`\"";

    /**
     * read the txt file and enter all the words into set and map.
     *
     * @param contentIn
     *            SimpleReader
     * @param content
     *            the map include all words and their occurrences
     * @param wordNum
     *            the set include all words
     * @requires contentIn should not be empty
     * @update content and wordNum
     * @ensures content and wordNum should not be empty, and all keys in the
     *          content must be the same as wordNum.
     */
    public static void contentInSetAndMap(SimpleReader contentIn,
            Set<String> content, Map<String, Integer> wordNum) {
        assert contentIn != null : "Violation of: txt file is not null";

        /*
         * Store all possible non-alphabetic symbols in a set.
         */
        Set<Character> sepSet = new Set1L<Character>();
        for (int i = 0; i < Separator.length(); i++) {
            sepSet.add(Separator.charAt(i));
        }

        /*
         * Read content in the file and write them into set and map.
         */
        while (!contentIn.atEOS()) {
            String eachLine = contentIn.nextLine();
            int pos = 0;
            while (pos < eachLine.length()) {
                String word = nextWordOrSeparator(eachLine, pos, sepSet);
                if (!sepSet.contains(word.charAt(0))) {
                    if (!(wordNum.hasKey(word))) {
                        wordNum.add(word, 1);
                        content.add(word);
                    } else {
                        /*
                         * If a word is already recorded, change the map value,
                         * and leaving the set unchanged.
                         */
                        int num = wordNum.value(word) + 1;
                        wordNum.replaceValue(word, num);
                    }
                }
                pos += word.length();
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param str
     *            the {@code String} from which to get the word or separator
     *            string
     * @param pos
     *            the starting index
     * @param sepSet
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code str} starting
     *         at index {@code pos}
     * @requires 0 <= pos < |str|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   str[pos, pos + |nextWordOrSeparator|)  and
     * if entries(str[pos, pos + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (pos + |nextWordOrSeparator| = |str|  or
     *    entries(str[pos, pos + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (pos + |nextWordOrSeparator| = |str|  or
     *    entries(str[pos, pos + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String str, int pos,
            Set<Character> sepSet) {
        assert str != null : "Violation of: str is not null";
        assert sepSet != null : "Violation of: separators is not null";
        assert 0 <= pos : "Violation of: 0 <= pos";
        assert pos < str.length() : "Violation of: pos < |str|";

        int endPos = -1;
        String word = "";
        /*
         * Use for loop to find the term's position.
         */
        for (int i = pos; i < str.length(); i++) {
            if (sepSet.contains(str.charAt(i)) && endPos == -1) {
                endPos = i;
            }
        }
        /*
         * Depending on the case, intercepts the corresponding substring.
         */
        if (endPos == pos) {
            word = str.substring(pos, endPos + 1);
        } else if (endPos == -1) {
            word = str.substring(pos);
        } else {
            word = str.substring(pos, endPos);
        }

        return word;
    }

    /**
     * compare two integers and return a value.
     */
    private static class CompareNum
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> p1,
                Map.Pair<String, Integer> p2) {
            return p2.value() - p1.value();
        }
    }

    /**
     * compare two strings and return a value.
     */
    private static class CompareString
            implements Comparator<Map.Pair<String, Integer>> {
        @Override
        public int compare(Map.Pair<String, Integer> p1,
                Map.Pair<String, Integer> p2) {
            return p1.key().toLowerCase().compareTo(p2.key().toLowerCase());
        }
    }

    /**
     * read the txt file and enter all the words into set and map.
     *
     * @param wordWithOccurrence
     *            the map include all words and their occurrences
     * @param sortingInt
     *            a SortingMachine for ints
     * @param sortingString
     *            a SortingMachine for strings
     * @param number
     *            the amount of the most frequent words
     * @return a String that record the maximum and the minimum occurrences
     * @requires wordWithOccurrence should not be empty
     * @ensures MaxMin need record "maximum value | minimum value"
     */
    private static String sortingMapKeyValue(
            Map<String, Integer> wordWithOccurrence,
            SortingMachine<Pair<String, Integer>> sortingInt,
            SortingMachine<Pair<String, Integer>> sortingString, int number) {
        assert wordWithOccurrence != null : "Violation of: the map is not null";
        assert number > 0 : "Violation of: Number must be positive";

        String maxMin = "";

        /*
         * Add all ints in SortingMachine.
         */
        for (Pair<String, Integer> p : wordWithOccurrence) {
            sortingInt.add(p);
        }

        /*
         * If the input number is larger than the amount of words in file,
         * report an error.
         */
        Reporter.assertElseFatalError(number <= sortingInt.size(),
                "number is too large");
        sortingInt.changeToExtractionMode();

        /*
         * Sort all ints and Strings.
         */
        for (int i = 0; i < number; i++) {
            Pair<String, Integer> p = sortingInt.removeFirst();
            if (i == 0) {
                maxMin = p.value().toString() + "|";
            }
            if (i == number - 1) {
                maxMin += p.value().toString();
            }
            sortingString.add(p);
        }
        sortingString.changeToExtractionMode();

        return maxMin;
    }

    /**
     * read the txt file and enter all the words into set and map.
     *
     * @param sortingString
     *            a SortingMachine for strings
     * @param out
     *            the output
     * @param htmlName
     *            the name of output file
     * @param maxMin
     *            a String that record the maximum and the minimum occurrences
     * @requires sortingString should not be empty, htmlName should not be
     *           empty, maxMin should not be empty
     */
    public static void writeHtml(
            SortingMachine<Pair<String, Integer>> sortingString,
            SimpleWriter out, String htmlName, String maxMin) {
        assert sortingString != null : "Violation of: the sortingString is not null";
        assert htmlName != null : "Violation of: the htmlName is not null";
        assert maxMin != null : "Violation of: the maxMin is not null";

        /*
         * Output front part of html.
         */
        out.println("<html>");
        out.println("  <head>");
        out.println("    <title>" + "Top " + sortingString.size() + " words in "
                + htmlName + "</title>");
        out.println(
                "    <link href=\"http://web.cse.ohio-state.edu/software/2231/web-sw2/assignments/projects/tag-cloud-generator/data/tagcloud.css\" rel =\"stylesheet\" type=\"text/css\"");
        out.println("  </head>");
        out.println("  <body>");
        out.println("    <h2> Top " + sortingString.size() + " words in "
                + htmlName + "</h2>");
        out.println("    <hr>");
        out.println("    <div class = \"cdiv\">");
        out.println("      <p class=\"cbox\">");

        /*
         * Subtract the maximum and minimum value from maxMin.
         */
        int symbolpos = maxMin.indexOf('|');
        int max = Integer.parseInt(maxMin.substring(0, symbolpos));
        int min = Integer.parseInt(maxMin.substring(symbolpos + 1));

        /*
         * Output each line of middle part of html.
         */
        final int maxTypeSize = 48;
        final int minTypeSize = 11;
        int length = sortingString.size();
        for (int i = 0; i < length; i++) {
            Pair<String, Integer> wordCount = sortingString.removeFirst();
            String word = wordCount.key();
            int numOfWords = wordCount.value();

            /*
             * Use a formula to calculate the type size of each word.
             */
            int typeSize = ((maxTypeSize - minTypeSize) * (numOfWords - min)
                    / (max - min)) + minTypeSize;

            out.println("        <span style=\"cursor:default\" class=\"" + "f"
                    + typeSize + "\" title=\"count: " + numOfWords + "\">"
                    + word + "</span>");
        }

        /*
         * Output last part of html.
         */
        out.println("      </p>");
        out.println("    </div>");
        out.println("  </body>");
        out.println("</html>");

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Ask the users to enter the txt file name they want to check.
         */
        out.println("Enter a txt file name: ");
        String fileName = in.nextLine();

        /*
         * Ask the users to enter the html file name they want to write in.
         */
        out.println("Enter a html file name: ");
        String htmlName = in.nextLine();

        /*
         * Ask the users to enter a number for the amount of the most frequent
         * words they want to check.
         */
        out.println(
                "Enter a positive number for the amount of the most frequent words: ");
        int num = in.nextInteger();
        while (!(num > 0)) {
            out.println(
                    num + " is not a positive number, enter another number: ");
            num = in.nextInteger();
        }

        /*
         * Build a set and map which will store the contents in txt files.
         */
        SimpleReader fileContent = new SimpleReader1L(fileName);
        Set<String> word = new Set1L<>();
        Map<String, Integer> wordWithOccurrence = new Map1L<>();
        contentInSetAndMap(fileContent, word, wordWithOccurrence);

        /*
         * If users' value is lager the amount of all word, just arrange all the
         * words in the txt file.
         */
        if (num > word.size()) {
            num = word.size();
        }

        /*
         * Sort ints and strings in map by using SortingMachine
         */
        Comparator<Map.Pair<String, Integer>> orderInt = new CompareNum();
        SortingMachine<Map.Pair<String, Integer>> orderIntMap = new SortingMachine1L<>(
                orderInt);
        Comparator<Map.Pair<String, Integer>> orderString = new CompareString();
        SortingMachine<Map.Pair<String, Integer>> orderStringMap = new SortingMachine1L<>(
                orderString);

        /*
         * Return a String that record the maximum and the minimum occurrences
         * int the map which called wordWithOccurrence.
         */
        String maxMin = sortingMapKeyValue(wordWithOccurrence, orderIntMap,
                orderStringMap, num);

        /*
         * Output the content in html format to a html file.
         */
        SimpleWriter htmlContent = new SimpleWriter1L(htmlName);
        writeHtml(orderStringMap, htmlContent, htmlName, maxMin);

        /*
         * Close all things.
         */
        fileContent.close();
        htmlContent.close();
        in.close();
        out.close();
    }
}
