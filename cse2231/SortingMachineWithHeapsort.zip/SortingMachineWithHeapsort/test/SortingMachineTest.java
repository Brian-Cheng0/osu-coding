import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsTest = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures <pre>
     * createFromArgsRef = (insertionMode, order, [multiset of entries in args])
     * </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    /*
     * Sample test cases.
     */

    @Test
    public final void testConstructor() {
        SortingMachine<String> m = this.constructorTest(ORDER);
        SortingMachine<String> mExpected = this.constructorRef(ORDER);
        assertEquals(mExpected, m);
    }

    @Test
    public final void testAddEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, true,
                "green");
        m.add("green");
        assertEquals(mExpected, m);
    }

    // TODO - add test cases for add, changeToExtractionMode, removeFirst,
    // isInInsertionMode, order, and size

    //Test for the insertion mode, false
    @Test
    public final void testInsertionModeFalse() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "cow");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "cow");

        boolean modeexpected = mexpected.isInInsertionMode();
        boolean mode = m.isInInsertionMode();

        assertEquals(modeexpected, mode);
        assertEquals(m, mexpected);
    }

    //Test for the insertion mode, true
    @Test
    public final void testInsertionModeTrue() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "cow");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, true,
                "cow");

        boolean modeexpected = mexpected.isInInsertionMode();
        boolean mode = m.isInInsertionMode();

        assertEquals(modeexpected, mode);

        m.changeToExtractionMode();
        mexpected.changeToExtractionMode();

        assertEquals(m, mexpected);
    }

    //Test for insertion mode when the sorting machine is empty, true
    @Test
    public final void testInsertionModeTrueEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, true);

        boolean modeexpected = mexpected.isInInsertionMode();
        boolean mode = m.isInInsertionMode();

        assertEquals(modeexpected, mode);
        assertEquals(m, mexpected);
    }

    //Test changing from insertion to extraction mode with no elements
    @Test
    public final void testExtractionModeEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false);

        m.changeToExtractionMode();

        assertEquals(mexpected, m);
    }

    //Test for changing mode
    @Test
    public final void testExtractionModeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "cow");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "cow");

        m.changeToExtractionMode();

        assertEquals(mexpected, m);
    }

    //Test for changing mode when elements are out of order
    @Test
    public final void testExtractionModeOutOfOrder() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "2",
                "1");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1", "2");

        m.changeToExtractionMode();

        assertEquals(mexpected, m);
    }

    //Test for removing first and making the sorting machine empty
    @Test
    public final void testRemoveFirst() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "1");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1");

        String test = m.removeFirst();
        String ref = mexpected.removeFirst();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for removing first and leaving the sorting machine filled
    @Test
    public final void testRemoveFirstNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "1",
                "2");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1", "2");

        String test = m.removeFirst();
        String ref = mexpected.removeFirst();

        assertEquals(ref, test);
        assertEquals(mexpected, m);
    }

    //Test for machine order on empty sorting machine
    @Test
    public final void testOrderEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, true);

        Comparator<String> test = m.order();
        Comparator<String> ref = mexpected.order();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for machine order on full sorting machine
    @Test
    public final void testOrderNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "1",
                "2");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1", "2");

        Comparator<String> test = m.order();
        Comparator<String> ref = mexpected.order();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for size in extraction mode
    @Test
    public final void testSizeEmptyExtraction() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false);

        int test = m.size();
        int ref = mexpected.size();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for size in extraction mode
    @Test
    public final void testSizeNonEmptyExtraction() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "1",
                "2");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1", "2");

        int test = m.size();
        int ref = mexpected.size();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for size in insertion mode
    @Test
    public final void testSizeNonEmptyInsertion() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "cow",
                "chicken");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, true,
                "cow", "chicken");

        int test = m.size();
        int ref = mexpected.size();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for size in insertion mode
    @Test
    public final void testSizeEmptyInsertion() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, true);

        int test = m.size();
        int ref = mexpected.size();

        assertEquals(test, ref);
        assertEquals(mexpected, m);
    }

    //Test for removing the first
    @Test
    public final void testRemoveFirstLargeHeap() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "1",
                "2", "3", "4", "5", "6", "7");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "1", "2", "3", "4", "5", "6", "7");

        String test = m.removeFirst();
        String ref = mexpected.removeFirst();

        assertEquals(ref, test);
        assertEquals(mexpected, m);
    }

    //Test for removing the first
    @Test
    public final void testRemoveFirstLargeRandom() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, false, "3",
                "2", "5", "6", "4", "7", "1");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "3", "2", "5", "6", "4", "7", "1");

        String test = m.removeFirst();
        String ref = mexpected.removeFirst();

        assertEquals(ref, test);
        assertEquals(mexpected, m);
    }

    //Test for adding one
    @Test
    public final void testAddNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true, "cow");
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "chicken", "cow");
        m.add("chicken");
        m.changeToExtractionMode();
        assertEquals(mexpected, m);
    }

    //Test for adding three
    @Test
    public final void testAddThree() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> mexpected = this.createFromArgsRef(ORDER, false,
                "cow", "chicken", "goat");
        m.add("cow");
        m.add("chicken");
        m.add("goat");
        m.changeToExtractionMode();
        assertEquals(mexpected, m);
    }

    //Test for adding three
    @Test
    public final void testAddThreeNonEmpty() {
        SortingMachine<String> m = this.createFromArgsTest(ORDER, true,
                "rabbit");
        SortingMachine<String> mExpected = this.createFromArgsRef(ORDER, false,
                "cow", "chicken", "rabbit", "goat");
        m.add("cow");
        m.add("chicken");
        m.add("goat");
        m.changeToExtractionMode();
        assertEquals(mExpected, m);
    }
}
