import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * prompt users to type the number which could not be 0 and negative number to
 * find the square root of number, the relative would be the number that the
 * users type.
 *
 * @author Yiming Cheng
 *
 */
public final class Newton4 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton4() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @param a
     *            relative error that users would accept
     * @return estimate of square root
     */
    private static double sqrt(double x, double a) {
        double r = x;
        /*
         * set r that is equal x as the initial value
         */
        while (Math.abs(r * r - x) / x > a * a) {
            r = (r + x / r) / 2;
            /*
             * calculate the right number of the square root within ε^2
             */
        }
        return r;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.println("Type a positive number");
        double number = in.nextDouble();
        while (number == 0) {
            /*
             * the number could not be 0
             */
            out.println("Type a positive number");
            number = in.nextDouble();
        }

        if (number < 0) {
            out.println("It is time to quit!");
            /*
             * the negative number would not have square root.
             */
        } else {
            out.println("Type a relative error");
            double error = in.nextDouble();
            /*
             * prompt the users to type the relative errors that they could
             * accept
             */
            /*
             * get the right answer of the square root
             */
            out.println(sqrt(number, error));

        }

        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}