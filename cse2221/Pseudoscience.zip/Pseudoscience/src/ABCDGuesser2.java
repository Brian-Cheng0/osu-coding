import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * The users are asked to type a constant number and 4 numbers which are
 * meaningful. When the list of the numbers are provided, the meaningful numbers
 * would combine with the list of the numbers to get the constant number that
 * are shown above.
 *
 * @author Yiming Cheng
 */
public class ABCDGuesser2 {

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        String positive = in.nextLine();

        while (!(FormatChecker.canParseDouble(positive))) {
            out.println("Type a mathamatical constant");
            positive = in.nextLine();
        }
        double positiveNumber = Double.parseDouble(positive);
        while (positiveNumber > 0) {
            positive = in.nextLine();
            positiveNumber = Double.parseDouble(positive);
        }

        return positiveNumber;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in,
            SimpleWriter out) {
        String real = in.nextLine();
        while (!(FormatChecker.canParseDouble(real))) {
            out.println("Type a numbers which is meaningful to you");
            real = in.nextLine();
        }
        double realNumber = Double.parseDouble(real);
        while (realNumber == 1.0) {
            real = in.nextLine();
            realNumber = Double.parseDouble(real);
        }
        return realNumber;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        out.println("Type a mathamatical constant");
        double u = getPositiveDouble(in, out);
        /*
         * People would be asked to type the numbers which are meaningful to
         * them.
         */
        out.println("Type a numbers which is meaningful to you");
        double w = getPositiveDoubleNotOne(in, out);
        out.println("Type a numbers which is meaningful to you");
        double x = getPositiveDoubleNotOne(in, out);
        out.println("Type a numbers which is meaningful to you");
        double y = getPositiveDoubleNotOne(in, out);
        out.println("Type a numbers which is meaningful to you");
        double z = getPositiveDoubleNotOne(in, out);
        /*
         * The list of numbers could combined with 4 meaningful numbers.
         */
        final double[] seriesNumber = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3,
                -1.0 / 4, 0, 1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };
        double estimate = 0;
        /*
         * The numbers which are used to find the closer number for the constant
         * number
         */
        int a = 0;
        int b = 0;
        int c = 0;
        int d = 0;
        /*
         * The numbers which is related to the closet number are shown.
         */
        double fA = 0;
        double fB = 0;
        double fC = 0;
        double fD = 0;
        final int percentage = 100;
        /*
         * Find the closest number to the number which the users type.
         */
        for (a = 0; a < (seriesNumber.length - 1); a++) {
            double num1 = Math.pow(w, seriesNumber[a]);
            for (b = 0; b < (seriesNumber.length - 1); b++) {
                double num2 = Math.pow(x, seriesNumber[b]);
                for (c = 0; c < (seriesNumber.length - 1); c++) {
                    double num3 = Math.pow(y, seriesNumber[c]);
                    for (d = 0; d < (seriesNumber.length - 1); d++) {
                        double num4 = Math.pow(z, seriesNumber[d]);
                        double estimateNumber = num1 * num2 * num3 * num4;
                        while (Math.abs(u - estimate) > Math
                                .abs(u - estimateNumber)) {
                            estimate = estimateNumber;
                            fA = seriesNumber[a];
                            fB = seriesNumber[b];
                            fC = seriesNumber[c];
                            fD = seriesNumber[d];
                        }
                    }
                }
            }
        }
        out.println(fA);
        out.println(fB);
        out.println(fC);
        out.println(fD);
        out.println("The closest number would be " + estimate);
        out.println("The relative error would be "
                + Math.abs(percentage * (1 - estimate / u)) + "%.");
    }
}
