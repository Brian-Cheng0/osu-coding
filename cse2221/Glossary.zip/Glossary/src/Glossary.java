import java.util.Comparator;

import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * The program is to prompt the user to enter the input file and generate an
 * index html page. In this way, several html pages would be generated with the
 * index html page.
 *
 * @author Yiming Cheng
 *
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * In order to sort the terms in an alphabetic order.
     *
     */
    private static class Order implements Comparator<String> {
        @Override
        public int compare(String s1, String s2) {
            return s1.compareTo(s2);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} which are got from the word
     * @param position
     *            the starting position of index
     * @param separators
     *            the certain punctuation which is from the list.
     * @return the first word or separator string in the index position
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        int endPos = -1;
        String word = "";
        int i = position;
        /*
         * find the corresponding substrings by separator
         */
        while (i < text.length()) {
            if (separators.contains(text.charAt(i)) && endPos == -1) {
                endPos = i;
            }
            if (endPos == -1) {
                word = text.substring(position, text.length());
            } else if (endPos == position) {
                word = text.substring(position, position + 1);
            } else {
                word = text.substring(position, endPos);
            }
            i++;
        }

        return word;

    }

    /**
     * generate the list of the input and process it to output into the map.
     *
     * @param word
     *            the map which are stored the data
     * @param in
     *            extract information from it
     * @return a queue storing a list of terms from the input file
     * @replaces word
     * @requires SimpleReader in is open, in contains at least a term and a
     *           definition, each pair of term and definition
     * @ensures Map word has a series of terms and the related definitions,
     *          Queue contains a list of terms
     */
    public static Queue<String> generateIn(Map<String, String> word,
            SimpleReader in) {
        assert word != null : "Violation of: word is not null";
        assert in != null : "Violation of: in is not null";

        Queue<String> summary = new Queue1L<>();
        /*
         * process the input into the map
         */
        while (!in.atEOS()) {
            String term = in.nextLine();
            String def = in.nextLine();
            String moreDef = " ";
            while (moreDef.length() > 0 && !in.atEOS()) {
                moreDef = in.nextLine();
                StringBuilder dDef = new StringBuilder(
                        def.length() + moreDef.length());
                dDef.append(def);
                dDef.insert(def.length(), moreDef);
                def = dDef.toString();
            }
            word.add(term, def);
            summary.enqueue(term);
        }
        return summary;
    }

    /**
     * distribute the string into the set.
     *
     * @param str
     *            the given {@code String}
     * @param charSet
     *            the {@code Set} to be replaced
     * @replaces charSet
     * @ensures charSet = entries(str)
     *
     */
    public static void generateElements(String str, Set<Character> charSet) {
        assert str != null : "Violation of: str is not null";
        assert charSet != null : "Violation of: charSet is not null";

        //find the right string for the set
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (!charSet.contains(ch)) {
                charSet.add(ch);
            }
        }

    }

    /**
     * generate several html pages to show the information.
     *
     * @param word
     *            the map which stores information
     * @param title
     *            title include a list of terms
     * @param outFolder
     *            name of the output folder
     * @restore title
     * @requires word is not empty, termsQ is not empty
     * @ensures create html pages corresponding to terms and definitions
     */
    public static void generateInfor(Map<String, String> word,
            Queue<String> title, String outFolder) {
        assert word != null : "Violation of: word is not null";
        assert title != null : "Violation of: title is not null";
        assert outFolder != null : "Violation of: outFolder is not null";
        /*
         * create the same queue as the title
         */
        Queue<String> tempTitle = title.newInstance();
        /*
         * create a loop to generate the children pages
         */
        while (title.length() > 0) {
            /*
             * find out whether the title includes terms
             */
            String term = title.dequeue();
            String dfn = word.value(term);
            tempTitle.enqueue(term);
            /*
             * generate html pages
             */
            SimpleWriter page = new SimpleWriter1L(
                    outFolder + "/" + term + ".html");
            page.println("<html>");
            page.println("<head>");
            page.println("<title>" + term + "</title>");
            page.println("</head>");
            page.println("<body>");
            page.println("</head>");
            page.println("<h2><b><i><font color=\"red\">" + term
                    + "</font></i></b></h2>");
            page.println("<blockquote>" + dfn + "</blockquote>");
            page.println("<hr />");
            page.println("<p>Return to <a href=\"index.html\">index</a>.</p>");
            page.println("</body>");
            page.println("</html>");
            page.close();
        }
        title.transferFrom(tempTitle);
    }

    /**
     * check if the the definition contains terms, and if the definition
     * contains a term, then change the related html page to make the term link
     * to the corresponding term page.
     *
     * @param word
     *            a map which stores terms and the related definitions
     * @param title
     *            contains a list of terms
     * @param strSet
     *            a set contains a series of special separators
     * @restore title
     * @requires word is not empty, title is not empty
     * @ensures change the definition format in the html page if the definition
     *          contains terms
     */
    public static void changeTheTerms(Map<String, String> word,
            Queue<String> title, Set<Character> strSet) {
        assert word != null : "Violation of: word is not null";
        assert title != null : "Violation of: title is not null";
        assert strSet != null : "Violation of: strSet is not null";

        Queue<String> temp = new Queue1L<>();
        int position = 0;
        while (title.length() > 0) {
            /*
             * extract terms and definitions into Strings
             */
            String term = title.dequeue();
            temp.enqueue(term);
            String dfn = word.value(term);
            String key = "";
            while (position < dfn.length()) {
                String str = nextWordOrSeparator(dfn, position, strSet);
                if (word.hasKey(str)) {
                    key += "<a href=\"" + str + ".html\">" + str + "</a>";
                } else {
                    StringBuilder kKey = new StringBuilder(
                            key.length() + str.length());
                    kKey.append(key);
                    kKey.insert(key.length(), str);
                    key = kKey.toString();
                }
                position = position + str.length();
            }
            /*
             * update the definition
             */
            word.replaceValue(term, key);
            position = 0;
        }
        title.transferFrom(temp);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * prompt the user to enter the input file
         */
        out.print("Please enter an input file: ");
        String file = in.nextLine();
        SimpleReader inFile = new SimpleReader1L(file);
        out.print("Please enter the folder to save files: ");
        String folder = in.nextLine();
        SimpleWriter outFile = new SimpleWriter1L(folder + "/index.html");
        /*
         * create a map to store terms and definitions create a queue to store
         * terms to prepare for the next steps
         */
        Map<String, String> wordMap = new Map1L<>();
        Queue<String> title = new Queue1L<>();
        title.append(generateIn(wordMap, inFile));
        /*
         * sort the terms in an alphabetic order
         */
        Comparator<String> od = new Order();
        title.sort(od);
        /*
         * generate an index page
         */
        Queue<String> temp = new Queue1L<>();
        outFile.println("<html>");
        outFile.println("<head>");
        outFile.println("<title>Glossary</title>");
        outFile.println("</head>");
        outFile.println("<body>");
        outFile.println("<h2>Glossary</h2>");
        outFile.println("<hr />");
        outFile.println("<h3>Index</h3>");
        outFile.println("<ul>");
        while (title.length() > 0) {
            String term = title.dequeue();
            temp.enqueue(term);
            outFile.println(
                    "<li><a href=\"" + term + ".html\">" + term + "</a></li>");
        }
        outFile.println("</ul>");
        outFile.println("</body>");
        outFile.println("</html>");
        title.transferFrom(temp);
        /*
         * use the separators to divide terms
         */
        Set<Character> charSet = new Set1L<>();
        final String separatorStr = " ,.:;!?";
        generateElements(separatorStr, charSet);

        changeTheTerms(wordMap, title, charSet);

        /*
         * generate several html pages for the user
         */
        generateInfor(wordMap, title, folder);

        /*
         * Close input and output streams
         */
        inFile.close();
        outFile.close();
        in.close();
        out.close();
    }

}
