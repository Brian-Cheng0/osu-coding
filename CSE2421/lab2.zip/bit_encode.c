/*BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE 
WORK  TO  CREATE  THIS  FILE  AND/OR  DETERMINE  THE  ANSWERS  FOUND  WITHIN  THIS 
FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR 
OR  GRADERS  OF  THIS  COURSE)  AND  I  HAVE  STRICTLY  ADHERED  TO  THE  TENURES  OF 
THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
THIS IS THE README FILE FOR LAB 2.

Student name: Yiming Cheng
*/
#include <stdio.h>
/*This program is to make an elementary level bit stream cipher which is an encryption algorithm that encrypts 1 byte of plain text at a time.
*/
int main()
{
    char decrypted[200];/*this is a text which is needed to be encrypted.*/
    int position=0;
    int i ,a =0;
    int number = 0;
    int len =0;
    int keys=0;
    int value;
    char letter;
    int left,right;
    #ifdef PROMPT
    printf("enter cleartext:\n");
    #endif
    while(letter!='\n'){/*prompt users to type the letter*/
        letter=getchar();
        decrypted[position] = letter;/*put letters into the array*/
        position++;
    }
    #ifdef PROMPT
    printf("\nText entered is :%s", decrypted);
    printf("\nHex encoding is:\n");   
    printf("enter 4-bit key: \n");
    #endif
    len = position-1;
    for(i = 0; i<len;i++){/*convert the letter to hex numbers*/
        value = decrypted[i-1];
    
        }
    while(position!='\n'){/*receive the number that users type*/
        position=getchar();
    
    if(position == '1'){/*move '1' to both two parts*/
        left=right=1;
        right=1<<number; 
        left=1<<(number+4);
    }else if(position=='0'){
        left=right=0; 
    }
    keys= keys|left|right;/*combine two parts into one 'keys'*/
    number++;

    }
    #ifdef PROMPT
    printf("hex ciphertext:\n");
    #endif
    for(a=0;a<len;a++){/*XOR all data*/
        value=decrypted[a]^keys ;
        printf(" %02x",value);
	#ifdef PROMPT
	if(a%10==0){
		printf("\n");
	}
	#endif
    }

}
