#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
void calculate(struct Node* newNode) {
	int cnt;
	cnt=0;
	/*this is the different category for the each student*/
	newNode->Student.Cat1.Cumulative = 0;
	if (newNode->Student.Cat1.score1 != -1) { cnt++;  newNode->Student.Cat1.Cumulative += newNode->Student.Cat1.score1; }
	if (newNode->Student.Cat1.score2 != -1) { cnt++;  newNode->Student.Cat1.Cumulative += newNode->Student.Cat1.score2; }
	if (newNode->Student.Cat1.score3 != -1) { cnt++;  newNode->Student.Cat1.Cumulative += newNode->Student.Cat1.score3; }
	if (cnt == 0) newNode->Student.Cat1.Cumulative = -1;
	else newNode->Student.Cat1.Cumulative /= cnt;

	cnt = 0;
	newNode->Student.Cat2.Cumulative = 0;
	if (newNode->Student.Cat2.score1 != -1) { cnt++;  newNode->Student.Cat2.Cumulative += newNode->Student.Cat2.score1; }
	if (newNode->Student.Cat2.score2 != -1) { cnt++;  newNode->Student.Cat2.Cumulative += newNode->Student.Cat2.score2; }
	if (newNode->Student.Cat2.score3 != -1) { cnt++;  newNode->Student.Cat2.Cumulative += newNode->Student.Cat2.score3; }
	if (cnt == 0) newNode->Student.Cat2.Cumulative = -1;
	else newNode->Student.Cat2.Cumulative /= cnt;

	cnt = 0;
	newNode->Student.Cat3.Cumulative = 0;
	if (newNode->Student.Cat3.score1 != -1) { cnt++;  newNode->Student.Cat3.Cumulative += newNode->Student.Cat3.score1; }
	if (newNode->Student.Cat3.score2 != -1) { cnt++;  newNode->Student.Cat3.Cumulative += newNode->Student.Cat3.score2; }
	if (newNode->Student.Cat3.score3 != -1) { cnt++;  newNode->Student.Cat3.Cumulative += newNode->Student.Cat3.score3; }
	if (cnt == 0) newNode->Student.Cat3.Cumulative = -1;
	else newNode->Student.Cat3.Cumulative /= cnt;

	cnt = 0;
	newNode->Student.Cat4.Cumulative = 0;
	if (newNode->Student.Cat4.score1 != -1) { cnt++;  newNode->Student.Cat4.Cumulative += newNode->Student.Cat4.score1; }
	if (newNode->Student.Cat4.score2 != -1) { cnt++;  newNode->Student.Cat4.Cumulative += newNode->Student.Cat4.score2; }
	if (newNode->Student.Cat4.score3 != -1) { cnt++;  newNode->Student.Cat4.Cumulative += newNode->Student.Cat4.score3; }
	if (cnt == 0) newNode->Student.Cat4.Cumulative = -1;
	else newNode->Student.Cat4.Cumulative /= cnt;

	newNode->Student.Current_Grade = 0;
    /*this is the different percentage of the category*/
	if (newNode->Student.Cat1.Cumulative == -1)
		newNode->Student.Current_Grade += 100 * 0.15;
	else
		newNode->Student.Current_Grade += newNode->Student.Cat1.Cumulative * 0.15;

	if (newNode->Student.Cat2.Cumulative == -1)
		newNode->Student.Current_Grade += 100 * 0.30;
	else
		newNode->Student.Current_Grade += newNode->Student.Cat2.Cumulative * 0.30;

	if (newNode->Student.Cat3.Cumulative == -1)
		newNode->Student.Current_Grade += 100 * 0.20;
	else
		newNode->Student.Current_Grade += newNode->Student.Cat3.Cumulative * 0.20;

	if (newNode->Student.Cat4.Cumulative == -1)
		newNode->Student.Current_Grade += 100 * 0.35;
	else
		newNode->Student.Current_Grade += newNode->Student.Cat4.Cumulative * 0.35;

	newNode->Student.Final_Grade = -1;
}