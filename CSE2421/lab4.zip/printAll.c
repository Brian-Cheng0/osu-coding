#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*thi is the grade of the students*/
void printAll(struct Node* head, char* Category_Names) {
    struct Node* temp ;
    double sumQ ;
    double sumM ;
    double sumH ;
    double sumF ;
    double sumG; 
    int cnt ;
    temp = head;
    sumQ = 0;
    sumM = 0;
    sumH = 0;
    sumF = 0;
    sumG = 0;
    cnt = 0;

    printHeader(Category_Names);
    while (temp != NULL)
    {
        printStudent(temp);
        sumQ += temp->Student.Cat1.Cumulative;
        sumM += temp->Student.Cat2.Cumulative;
        sumH += temp->Student.Cat3.Cumulative;
        sumF += temp->Student.Cat4.Cumulative;
        sumG += temp->Student.Current_Grade;
        cnt++;
        temp = temp->next;
    }
    printf("\nClass Averages for Quizzes: %.2f, Midterms: %.2f, Homework: %.2f, Final: %.2f Current Grade  %.2f\n", sumQ / cnt, sumM / cnt, sumH / cnt, sumF / cnt, sumG / cnt);
}