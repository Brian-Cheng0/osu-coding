#include"lab4.h"
#include <string.h>
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
int main(int argc, char* argv[])
{
    struct Node* last;
    struct Node* temp ;
	struct Node* head;
	FILE* file;
	char Category_Names[100];
    int total ;       
    int i;
              
    
    
    void (*p[7])(struct Node*, char*) ;
    total=0;  
    /*make the linked list of the Category_Names*/
	head=readFile(argv[1],Category_Names,&total);
	
    printf("Reading student information from file \"%s\",\n", argv[1]);
    printf("A total of %d student records were read from the file class_records\n", total);
	 p[0]= printLine;
	p[1]=printLineByLastName ;
	p[2]=printAll ;
	p[3]=recalculate;
	p[4]=recalculateAll;
	p[5]=insertScore;
	p[6]=calculateFinal;
	while (1)
	{
	    /*print the functions of the instructions*/
        printf("\nPlease enter an option between 1 and 10:\n" \
            "1)  Print Student Scores by Student ID\n" \
            "2)  Print Student Scores by Last Name\n" \
            "3)  Print Student Scores for All Students\n" \
            "4)  Recalculate Student Scores for a Single Student ID\n" \
            "5)  Recalculate All Student Scores\n" \
            "6)  Insert a score for a specific Student ID\n" \
            "7)  Calculate Final Grades\n" \
            "8)  Add a new student\n" \
            "9)  Delete a student\n" \
            "10) Exit Program\n");

        printf("\nOption:  ");
        scanf("%d", &i);
        switch (i)
        {
        case 1: {
            p[i - 1](head, Category_Names);;
            break;
            }
        case 2: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 3: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 4: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 5: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 6: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 7: {
            p[i - 1](head, Category_Names);
            break;
        }
        case 8: {
            head = addNewStudent(head, Category_Names);
            break;
        }
        case 9: {

            head = delAStudent(head, Category_Names);
            break;
        }
        case 10: {
        /*this function is to output a file with the information*/
        file= fopen(argv[2], "w");     
            if (!file)
                return -1;
            Category_Names[7] = ' ';
            Category_Names[16] = ' ';
            Category_Names[25] = ' ';
            fprintf(file, "%s\n", Category_Names);	

            temp = head;
            while (temp != NULL)
            {
                fprintf(file, "%s\n%d\n", temp->Student.student_name, temp->Student.student_ID);
                fprintf(file, "%f\t%f\t%f\n", temp->Student.Cat1.score1, temp->Student.Cat1.score2, temp->Student.Cat1.score3);
                fprintf(file, "%f\t%f\t%f\n", temp->Student.Cat2.score1, temp->Student.Cat2.score2, temp->Student.Cat2.score3);
                fprintf(file, "%f\t%f\t%f\n", temp->Student.Cat3.score1, temp->Student.Cat3.score2, temp->Student.Cat3.score3);
                fprintf(file, "%f\t%f\t%f\n", temp->Student.Cat4.score1, temp->Student.Cat4.score2, temp->Student.Cat4.score3);
                last = temp;
                temp = temp->next;
                free(last);
            }
            printf("A total of %d student records were written to file %s", total, argv[2]);
            return 0;
        }
        default:
            break;
        }
	}
	printLine(head, Category_Names);
	return 0;
}