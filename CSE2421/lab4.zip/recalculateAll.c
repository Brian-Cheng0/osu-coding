#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*calculate all data for the student*/
void recalculateAll(struct Node* head, char* Category_Names) {
    struct Node* temp;
   temp= head;
    while (temp != NULL)
    {
        calculate(temp);
        printf("Student Name: %-25s ", temp->Student.student_name);
        printf("Quizzes Cumlative :%6.2f", temp->Student.Cat1.Cumulative);

        printf("       Midterms Cumlative: %6.2f", temp->Student.Cat2.Cumulative);

        printf("       Homework Cumlative : %6.2f", temp->Student.Cat3.Cumulative);

        printf("      Final Cumlative: %6.2f", temp->Student.Cat4.Cumulative);

        printf(" Current Grade is:  %6.2f\n", temp->Student.Current_Grade);

        temp = temp->next;
    }
}