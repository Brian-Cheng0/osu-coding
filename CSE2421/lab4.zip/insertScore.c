#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
void insertScore(struct Node* head, char* Category_Names) {
	struct Node* NodePtr;
	int StudentID;
		int choice;
	float score;
	/*the user could type ID for the corrsponding information*/
	printf("Enter the Student ID #: ");
	scanf("%i", &StudentID);
	printf("Hunting for %d\n", StudentID);

	NodePtr = get_NodeforID(head, StudentID);

	if (NodePtr == NULL) {
		printf("\nERROR: Student ID number %i was not found in the list\n", StudentID);
	}
	else {
		printf("Insert a Score for Mancilla, Sarai ?  Enter 1, if yes. Enter 2, if no:  ");

		scanf("%d", &choice);
		if (choice == 1) {
			printf("Which category?\n1) Quizzes\n2) Midterms\n3) Homework\n4) Final\n");
			scanf("%d", &choice);
			switch (choice)
			{
				case 1:
				{
					printf("Which score?\nEnter 1, 2, or 3\n");
					scanf("%d", &choice);
					switch (choice)
					{
						case 1:
						{
						
							printf("Enter New Score:  ");
							scanf("%f", &score);
							NodePtr->Student.Cat1.score1 = score;
							break;
						}
						case 2:
						{
							float score;
							printf("Enter New Score:  ");
							scanf("%f", &score);
							NodePtr->Student.Cat1.score2 = score;
							break;
						}
						case 3: {
							float score;
							printf("Enter New Score:  ");
							scanf("%f", &score);
							NodePtr->Student.Cat1.score3 = score;
							break;
						}
						default: {
							printf("\nERROR: Invalid score\n");
							return;
						}
					}
					break;
				}
			case 2:
			{
				printf("Which score?\nEnter 1, 2, or 3\n");
				scanf("%d", &choice);
				switch (choice)
				{
				case 1:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat2.score1 = score;
					break;
				}
				case 2:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat2.score2 = score;
					break;
				}
				case 3: {
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat2.score3 = score;
					break;
				}
				default: {
					printf("\nERROR: Invalid score\n");
					return;
				}
				}
				break;
			}
			case 3:
			{
				printf("Which score?\nEnter 1, 2, or 3\n");
				scanf("%d", &choice);
				switch (choice)
				{
				case 1:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat3.score1 = score;
					break;
				}
				case 2:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat3.score2 = score;
					break;
				}
				case 3: {
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat3.score3 = score;
					break;
				}
				default: {
					printf("\nERROR: Invalid score\n");
					return;
				}
				}
				break;
			}
			case 4:
			{
				printf("Which score?\nEnter 1, 2, or 3\n");
				scanf("%d", &choice);
				switch (choice)
				{
				case 1:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat4.score1 = score;
					break;
				}
				case 2:
				{
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat4.score2 = score;
					break;
				}
				case 3: {
					float score;
					printf("Enter New Score:  ");
					scanf("%f", &score);
					NodePtr->Student.Cat4.score3 = score;
					break;
				}
				default: {
					printf("\nERROR: Invalid score\n");
					return;
				}
				}
				break;
			}
			default: {
				printf("\nERROR: Invalid category\n");
				return;
			}
			}
			printHeader(Category_Names);
			printStudent(NodePtr);
		}
	}
}