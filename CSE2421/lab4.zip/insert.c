#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
struct Node* insert(struct Node* head, struct Node* in) {
	struct Node* temp;
	struct Node* last;
	temp=head;
	if (in == head)return head;
	if (in->Student.student_ID < head->Student.student_ID) {
		in->next = head;
		return in;
	}
	while (temp!=NULL)
	{
		if (temp->Student.student_ID > in->Student.student_ID) {
			last->next = in;
			in->next = temp;
			return head;
		}
		last = temp;
		temp = temp->next;
	}
	last->next = in;
	in->next = NULL;
	return head;
}