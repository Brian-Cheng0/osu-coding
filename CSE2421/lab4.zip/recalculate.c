#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*calculate the information again*/
void recalculate(struct Node* head, char* Category_Names) {
	int StudentID;
	struct Node* NodePtr;
	printf("What is the Student ID for the scores you want to recalculate?\n Student ID:  ");
	scanf("%i", &StudentID);

	
	NodePtr = get_NodeforID(head, StudentID);


	if (NodePtr == NULL) {
		printf("\nERROR: Student ID number %i was not found in the list\n", StudentID);
	}
	else {
		calculate(NodePtr);
		printf("Recalculating grades for %s , Student ID Number: %d\n", NodePtr->Student.student_name, NodePtr->Student.student_ID);
		if (NodePtr->Student.Cat1.Cumulative == -1)printf("Student's Quizzes Cumlative was deleted");
		else		printf("Quizzes Cumlative:  %.2f\n", NodePtr->Student.Cat1.Cumulative);

		if (NodePtr->Student.Cat2.Cumulative == -1)printf("Student's Midterms Cumlative was deleted");
		else		printf("Midterms Cumlative:  %.2f\n", NodePtr->Student.Cat2.Cumulative);

		if (NodePtr->Student.Cat3.Cumulative == -1)printf("Student's Homework Cumlative was deleted");
		else		printf("Homework Cumlative:  %.2f\n", NodePtr->Student.Cat3.Cumulative);

		if (NodePtr->Student.Cat4.Cumulative == -1)printf("Student's Final Cumlative was deleted");
		else		printf("Final Cumlative is:  %.2f\n", NodePtr->Student.Cat4.Cumulative);

		if (NodePtr->Student.Current_Grade == -1)printf("Student's Current Grade was deleted");
		else		printf("Current Grade is:  %.2f\n", NodePtr->Student.Current_Grade);

		if (NodePtr->Student.Final_Grade== -1)printf("Student's Final Grade was deleted\n");
		else		printf("Final Grade is:  %.2f\n", NodePtr->Student.Final_Grade);
	}
}