#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*this function is to calculate the final grade for student*/
void calculateFinal(struct Node* head, char* Category_Names) {
	struct Node* temp = head;
    double sumQ ;
    double sumM ;
    double sumH ;
    double sumF ;
    double sumG;
    double sumFinal ;
    int cnt ;
    sumQ = 0;
    sumM = 0;
    sumH = 0;
    sumF = 0;
    sumG = 0;
    cnt = 0;
	sumFinal = 0;
	head->Student.Final_Grade = 0;
	while (head != NULL)
	{
		if (head->Student.Cat1.Cumulative == -1)
			head->Student.Final_Grade += 0;
		else
			head->Student.Final_Grade += head->Student.Cat1.Cumulative * 0.15;

		if (head->Student.Cat2.Cumulative == -1)
			head->Student.Final_Grade += 0;
		else
			head->Student.Final_Grade += head->Student.Cat2.Cumulative * 0.30;

		if (head->Student.Cat3.Cumulative == -1)
			head->Student.Final_Grade += 0;
		else
			head->Student.Final_Grade += head->Student.Cat3.Cumulative * 0.20;

		if (head->Student.Cat4.Cumulative == -1)
			head->Student.Final_Grade += 0;
		else
			head->Student.Final_Grade += head->Student.Cat4.Cumulative * 0.35;

		head = head->next;
	}
	head = temp;
	printHeader(Category_Names);
	while (head != NULL)
	{
		printStudent(head);
		sumQ += head->Student.Cat1.Cumulative;
		sumM += head->Student.Cat2.Cumulative;
		sumH += head->Student.Cat3.Cumulative;
		sumF += head->Student.Cat4.Cumulative;
		sumG += head->Student.Current_Grade;
		head = head->next;
		cnt++;
	}
	printf("\nClass Averages for Quizzes: %.2f, Midterms: %.2f, Homework: %.2f, Final: %.2f Current Grade  %.2f\n", sumQ / cnt, sumM / cnt, sumH / cnt, sumF / cnt, sumG / cnt);

}