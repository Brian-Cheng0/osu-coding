#include<stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include<string.h>

struct Cat_Grade {
    float score1;
    float score2;
    float score3;
    float Cumulative;
};
struct Data {
    char student_name[40];
    int student_ID;
    struct Cat_Grade Cat1;
    struct Cat_Grade Cat2;
    struct Cat_Grade Cat3;
    struct Cat_Grade Cat4;
    float Current_Grade;
    float Final_Grade;
};

typedef struct Node {
    struct Data Student;
    struct Node* next;
} Node;

void printHeader(char* Category_Names);
void printLine(struct Node* head, char* Category_Names);
void printStudent(struct Node* NodePtr);
struct Node* readFile(const char* file_name,char Category_Names[],int* total);
struct Node* insert(struct Node* head, struct Node* in);
struct Node* get_NodeforID(struct Node* head, int id);
void printLineByLastName(struct Node* head, char* Category_Names);
void recalculate(struct Node* head, char* Category_Names);
void calculate(struct Node* newNode);
void insertScore(struct Node* head, char* Category_Names);
void calculateFinal(struct Node* head, char* Category_Names);
struct Node* addNewStudent(struct Node* head, char* Category_Names);
struct Node* delAStudent(struct Node* head, char* Category_Names);
void printAll(struct Node* head, char* Category_Names);
void recalculateAll(struct Node* head, char* Category_Names);