#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
void printStudent(struct Node* NodePtr) {
/*print the information about students*/
	printf("%-20s\t  %5d", NodePtr->Student.student_name, NodePtr->Student.student_ID);

	if (NodePtr->Student.Cat1.score1 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat1.score1);

	if (NodePtr->Student.Cat1.score2 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat1.score2);

	if (NodePtr->Student.Cat1.score3 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat1.score3);

	if (NodePtr->Student.Cat1.Cumulative == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat1.Cumulative);



	if (NodePtr->Student.Cat2.score1 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat2.score1);

	if (NodePtr->Student.Cat2.score2 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat2.score2);

	if (NodePtr->Student.Cat2.score3 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat2.score3);

	if (NodePtr->Student.Cat2.Cumulative == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat2.Cumulative);



	if (NodePtr->Student.Cat3.score1 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat3.score1);

	if (NodePtr->Student.Cat3.score2 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat3.score2);

	if (NodePtr->Student.Cat3.score3 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat3.score3);

	if (NodePtr->Student.Cat3.Cumulative == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat3.Cumulative);



	if (NodePtr->Student.Cat4.score1 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat4.score1);

	if (NodePtr->Student.Cat4.score2 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat4.score2);

	if (NodePtr->Student.Cat4.score3 == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat4.score3);

	if (NodePtr->Student.Cat4.Cumulative == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Cat4.Cumulative);


	if (NodePtr->Student.Current_Grade == -1)printf("     n/a");
	else printf("%8.2f", NodePtr->Student.Current_Grade);

	if (NodePtr->Student.Final_Grade == -1)printf("     n/a\n");
	else printf("%8.2f\n", NodePtr->Student.Final_Grade);
}