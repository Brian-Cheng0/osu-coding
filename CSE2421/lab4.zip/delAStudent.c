#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
struct Node* delAStudent(struct Node* head, char* Category_Names) {
	struct Node* NodePtr;
	int StudentID;
	int c;	
	struct Node* temp ;
	struct Node* last;
	/*get the ID from the users*/
	printf("Please enter the student ID  number you wish to delete, followed by enter.\n");
	scanf("%i", &StudentID);
	printf("Hunting for %d\n", StudentID);

	/*fetch the ID for the student*/
	NodePtr = get_NodeforID(head, StudentID);

	/*we could find whether the ID is existed or not*/
	if (NodePtr == NULL) {
		printf("\nERROR: Student ID number %i was not found in the list\n", StudentID);
		return head;
	}
	else {
		printf("Do you really want to delete student ID number %d, %s ?\nIf yes, enter 1.  If no, enter 2:  ",NodePtr->Student.student_ID ,NodePtr->Student.student_name );

		scanf("%d", &c);
		if (c != 1) {
			return head;
		}
		printf("student ID number %d, %s  has been deleted.\n", NodePtr->Student.student_ID, NodePtr->Student.student_name);
		temp = head->next;

		if (head->Student.student_ID==StudentID) {
			last = head->next;
			free(head);
			return last;
		}
		while (temp != NULL)
		{
			if (temp->Student.student_ID == StudentID) {
				last->next = temp->next;
				free(temp);
				return head;
			}
			last = temp;
			temp = temp->next;
		}
		return head;
	}
}