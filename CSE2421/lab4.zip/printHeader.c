#include "lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*the header of the information*/
void printHeader(char *Category_Names)
{
	printf("\nStudent Name       Student ID#\t\t%s\t\t\t\t%s\t\t\t%s\t\t\t%s\t\t\t\tCurrent\tFinal\n",
	Category_Names,(char*)Category_Names+8,(char *)Category_Names+17,(char *)Category_Names+26);
	printf("                                  1       2       3       Cum      1       2       3     Cum       1       2       3       Cum     1       2       3      Cum   Grade   Grade\n");

}

