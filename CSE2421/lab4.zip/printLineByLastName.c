#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*searching students by the last name*/
void printLineByLastName(struct Node* head, char* Category_Names) {
	struct Node* NodePtr,* t ,* temp;
	char name[40];
	int index;
	int cnt ;

	printf("Enter the Student's Last Name: ");
	scanf("%s", name);
	printf("Hunting for %s\n", name);
	t = NULL;
	cnt = 0;
	temp = head;

	while (head!=NULL)
	{
		if (strstr(head->Student.student_name, name) != NULL) {
			if (cnt == 1) {
				printf("There is more than one student by that name.\n");
			}
			if (cnt >= 1) {
				printf("%d) %s\n", cnt, t->Student.student_name);
			}
			t = head;
			cnt++;
		}
		head = head->next;
	}
	if (cnt == 1) {
		printHeader(Category_Names);
		printStudent(t);
	}
	else if (cnt > 1) {
		printf("%d) %s\n", cnt,  t->Student.student_name);
		printf("Please indicate which student you want: " );
		scanf("%d", &index);
		if (index < 0 || index >= cnt) {
			printf("\nERROR: Index out of range\n");
		}
		else {
			head = temp;
			cnt = 0;
			while (head != NULL)
			{
				if (strstr(head->Student.student_name, name) != NULL) {
					cnt++;
					if (cnt == index) {
						printHeader(Category_Names);
						printStudent(head);
						break;
					}
				}
				head = head->next;
			}
		}
	}
	else {
		printf("\nERROR: Student Last Name %s was not found in the list\n", name);
	}
}