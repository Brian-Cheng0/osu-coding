#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/* this is the struct of the new student information*/
struct Node* addNewStudent(struct Node* head, char* Category_Names) {
	struct Node* newNode ;
		struct Node* NodePtr;
		int StudentID;
	newNode = (struct Node*)malloc(sizeof(struct Node));
	printf("Enter the Student's Name: ");
	scanf(" %[^\n]", newNode->Student.student_name);
	while (1) {
		printf("Enter the Student's ID Number: ");
		scanf("%i", &StudentID);
		printf("Hunting for %d\n", StudentID);

		/*By using this function, we could find the right one student information*/
		NodePtr = get_NodeforID(head, StudentID);

		/*We could find whether the id is duplicate or not*/
		if (NodePtr != NULL) {
			printf("Student ID Number entered was a duplicate.\n");
		}
		else {
			newNode->Student.student_ID = StudentID;
			printf("Enter first Quizzes score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat1.score1);
			printf("Enter second Quizzes score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat1.score2);
			printf("Enter third Quizzes score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat1.score3);

			printf("Enter first Midterms score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat2.score1);
			printf("Enter second Midterms score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat2.score2);
			printf("Enter third Midterms score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat2.score3);

			printf("Enter first Homework score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat3.score1);
			printf("Enter second Homework score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat3.score2);
			printf("Enter third Homework score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat3.score3);

			printf("Enter first Final score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat4.score1);
			printf("Enter second Final score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat4.score2);
			printf("Enter third Final score (use -1 if there is no score): ");
			scanf("%f", &newNode->Student.Cat4.score3);
			printf("%s, Student ID# %d has been added with the following information:\n",newNode->Student.student_name,newNode->Student.student_ID);
			
			calculate(newNode);
			
			printHeader(Category_Names);
			printStudent(newNode);
			return insert(head, newNode);
			
		}
	}
}