#include"lab4.h"
/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF 
THE WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN 
THIS FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE 
INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE 
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
    */
/*get the information and make a linked list*/
struct Node* readFile(const char* file_name,char Category_Names[],int* total)
{
	char line[1024] ;
	FILE* file ;
	int l;
	int i,j;
	struct Node* head, * last,*newNode;
	struct Node* t;
	file= fopen(file_name, "rt");
	if (!file)
		return NULL;

	fgets(line, sizeof(line), file);
	l = strlen(line);
	strcpy(Category_Names, line);
	Category_Names[strlen(line)-1] = '\0';
	for (i = 0; i < l; i++)
	{
		if (Category_Names[i] == ' ') {
			Category_Names[i] = '\0';
		}
	}
	printf("%s", Category_Names);
	newNode = (struct Node*)malloc(sizeof(struct Node));
	head = newNode;
	newNode->next = NULL;
	while (fgets(newNode->Student.student_name, sizeof(newNode->Student.student_name), file))
	{
		newNode->Student.student_name[strlen(newNode->Student.student_name) - 1] = '\0';
		if (strlen(newNode->Student.student_name) == 0)break;
		fscanf(file, "%d", &newNode->Student.student_ID);
		fscanf(file, "%f %f %f", &newNode->Student.Cat1.score1, &newNode->Student.Cat1.score2, &newNode->Student.Cat1.score3);
		fscanf(file, "%f %f %f", &newNode->Student.Cat2.score1, &newNode->Student.Cat2.score2, &newNode->Student.Cat2.score3);
		fscanf(file, "%f %f %f", &newNode->Student.Cat3.score1, &newNode->Student.Cat3.score2, &newNode->Student.Cat3.score3);
		fscanf(file, "%f %f %f", &newNode->Student.Cat4.score1, &newNode->Student.Cat4.score2, &newNode->Student.Cat4.score3);

		calculate(newNode);


		head = insert(head, newNode);
		last = newNode;
		newNode =  (struct Node*)malloc(sizeof(struct Node));
		fgets(line, sizeof(line), file);
		(*total)++;
	}
	last->next = NULL;
	free(newNode);
	fclose(file);
    t = head;
	return head;
}