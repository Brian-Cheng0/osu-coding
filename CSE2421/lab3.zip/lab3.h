void getNumberOfBooks(char **bookList, int books);

void getFavorites(char **bookList, char ***favoriteList, int favorites);

void printToFile(char **bookList, char ***favoriteList, int favorites, int books, int choice);
