/*
*Name: Yiming Cheng
* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
* WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
* FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
* OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
* OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
*
*This program is to ask the users to type the numbers of books and the names of 
*books.Then the users would type their favorites books as a list.
*/
#include <stdio.h>
#include <stdlib.h>

/*this method is to get the number and the list of books that users want to read*/
void getNumberOfBooks(char **bookList,int books){
    int n = 0;
    int i;
    
    printf("Enter the %d book titles one to a line:", books);
    /*make the dynamic memory for the list of books*/
    while(n<books){
        *(bookList+n) = calloc(61, sizeof(char));
        n++;
    }
    /*get the list of books from users*/
    for(i = 0;i<books;i++){
        scanf(" %[^\n]",*(bookList + i));
    }
    i = 0;
    /*print the list of books for users*/
    printf("You've entered:\n");
    for(i = 0; i<books;i++){
        printf("%d. %s\n", (i+1), *(bookList + i));
    }
}
/*this method could print the favorite book list for users*/
void getFavorites(char **bookList, char ***favoriteList, int favorites){
    int n = 0;
    int i = 0;
    printf("Enter the number next to each book title you want on your favorites list:\n");
    /*get the list of favorite books from users*/
    while(n<favorites){
        scanf("%d",&i);
        *(favoriteList+n)=(bookList+i-1);
        n++;
    }
    n=0;
    printf("\nThe books on your favorites list are:\n");
    /*print the list of favorite books for users*/
    for(n = 0;n<favorites;n++){
        printf("%s\n",**(favoriteList+n));
    }
}
/*this method for users to store the list of books and favorite books*/
void printToFile(char **bookList, char ***favoriteList, int favorites, int books, int choice){
    char name[256];
    FILE *out_File;
    int n = 0;
    /*ask users whether users want to save the file and prompt users to type the filename*/
    if(choice==1){
        printf("What file name do you want to use? ");
        scanf("%[^\n]", name);
        out_File = fopen(name, "w");
    }
    /*print the list of books for users in the file*/
    fprintf(out_File, "Books I’ve Read:\n");
    while(n<books){
        fprintf(out_File, "%s\n", *(bookList+n));
    }
    n=0;
    fprintf(out_File,"\n");
    fprintf(out_File, "\nMy Favorites are:\n");
    /*print the list of favorite books for users in the file*/
    while(n<favorites){
        fprintf(out_File, "%s\n", **(favoriteList+n));
    }
    fprintf(out_File,"\n");
}
int main()
{   
    int books;
    char **bookList;
    int favorites;
    char ***favoriteList;
    char bookName;
    int choice;
    int n;
    printf("How many library book titles do you plan to enter?");
    scanf("%d%*c", &books);
    /*make memory for the users to store the book list*/
    bookList = (char **)calloc(books, sizeof(char *));
    getNumberOfBooks(bookList, books);
    printf(" Of those %d books, how many do you plan to put on your favorites list?", books);
    scanf("%d%*c", &favorites);
    /*make memory for the users to store the favorite book list*/
    favoriteList = (char ***)calloc(favorites, sizeof(char **));
    getFavorites(bookList, favoriteList, favorites);
    /*ask users whether they want to save the file*/
    printf("Do you want to save them(1=yes, 2=no):\n");
    scanf("%d", &choice);
    printToFile(bookList,favoriteList, favorites, books, choice);
    printf("Your booklist and favorites have been saved to the file booksIveRead.");
    /*free the pointers memory */
    while(n<books){
        if(*(bookList+n)!=NULL){
            free(*(bookList+n));
        }
    }
    free(bookList);
    free(favoriteList);
    return 0;
}
