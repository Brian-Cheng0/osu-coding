#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <stdlib.h>

#define BUFFSIZE 10000


int main(int argc, char *argv[])
{
	int sd; /* socket descriptor */
	int connected_sd; /* socket descriptor */
	int rc; /* return code from recvfrom */
	struct sockaddr_in server_address;
	struct sockaddr_in from_address;
	char buffer[BUFFSIZE];
	int flags = 0;
	socklen_t fromLength;
	int portNumber;

	int file;
	int sizeOfFilename;
	int totalByte;
	int totalReadByte = 0;
	int filesize;
	FILE *output;

	if (argc < 2){
		printf ("Usage is: ftps <portNumber>\n");
		exit (1);
	}
	//create the connection between the server and client.
	portNumber = atoi(argv[1]);
	sd = socket (AF_INET, SOCK_STREAM, 0);
	fromLength = sizeof(struct sockaddr_in);
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(portNumber);
	server_address.sin_addr.s_addr = INADDR_ANY;
	rc = bind (sd, (struct sockaddr *)&server_address, sizeof(server_address));
	if (rc < 0) {
        perror("bind");
        exit(1);
    }
	listen (sd, 5);
		connected_sd = accept (sd, (struct sockaddr *) &from_address, &fromLength);
		if (rc < 0) {
            perror("exit");
            exit(1);
        }
		while(1){
		totalReadByte = 0;
		totalByte = 0;
		char outputFilename[100];
		int sizeOfFilename;
		//read the size of file from client
		rc = read(connected_sd, &sizeOfFilename, sizeof(int));
		sizeOfFilename = ntohl(sizeOfFilename);
		//read the file name from the client.
		rc = read(connected_sd, outputFilename, sizeOfFilename);
		printf("The file size is %d bytes, the receiving filename is %s\n", sizeOfFilename, outputFilename);
		//receive the length of the total bytes.
		rc = read(connected_sd, &totalByte, sizeof(int));
		if ((output = fopen(outputFilename, "wb")) == NULL) {
					printf("Error opening the output file '%s'\n", outputFilename);
					exit(1);
				}
		while (totalReadByte < totalByte) {
			rc = read(connected_sd, buffer, sizeof(buffer));
			fwrite(buffer, 1, rc, output);
			totalReadByte += rc;
			}
		printf("the size of the file is %d bytes, the size of the file is %d by reading each line.\n", totalByte, totalReadByte);
		fclose(output);

		int sendback = htonl(totalReadByte);
		rc = write(connected_sd, &sendback, sizeof(int));
		printf("Send files size of %d bytes by ACK.\n", totalReadByte);
	
		

		
		
	}
    
    
	return 0;
}
