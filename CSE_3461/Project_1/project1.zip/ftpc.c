#include <string.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>

#define BUFFSIZE 1000
int readfile(FILE *inputFile);
int getFileLength(FILE *fp);


// int readfile(FILE *inputFile) {
// 	int rc;
//     unsigned char buffer[BUFFSIZE];
//     int numberOfBytes;
//     int totalBytesRead = 0;
	
// 	numberOfBytes = fread(buffer, 1, BUFFSIZE, inputFile);
//     while (numberOfBytes > 0) {
//         totalBytesRead += numberOfBytes;
// 		numberOfBytes = fread(buffer, 1, BUFFSIZE, inputFile);
//     }

//     fclose(inputFile);
//     return totalBytesRead;
// }

int getFileLength(FILE* fp)
{
    fseek(fp, 0, SEEK_END);
    int len = (int) ftell(fp);
    fseek(fp, 0, SEEK_SET);
    return len;
}

int main(int argc, char *argv[])
{	
	FILE *inputFile;
	char inputFilename[100];
	char file[100];
	int totalBytes = 0;
	int sd;
	struct sockaddr_in server_address;
	int portNumber;
	char serverIP[29];
	int rc = 0;
	int totalReadByte = 0;
	char buffer[BUFFSIZE];
    int numberOfBytes = 0;
	int receiveBytes;

	if (argc < 3){
		printf ("usage is ftpc <ipaddr> <port>\n");
		exit(1);
	}

	strcpy(inputFilename, ""); // Initialize the string
	sd = socket(AF_INET, SOCK_STREAM, 0);
	portNumber = strtol(argv[2], NULL, 10);
	strcpy(serverIP, argv[1]);
	server_address.sin_family = AF_INET;
	server_address.sin_port = htons(portNumber);
	server_address.sin_addr.s_addr = inet_addr(serverIP);

	

	if(connect(sd, (struct sockaddr *)&server_address, sizeof(struct sockaddr_in)) < 0) {
		close(sd);
		perror("error connecting stream socket");
		exit(1);
	}
	//ask the file from the user
	printf("What is the file you'd like to send?  ");
    scanf("%s", file);
	while(strcmp(file, "DONE")){
		totalBytes = 0;
		totalReadByte = 0;
		int sizeOfFilename = htonl(strlen(file));
		//send the size of the file to the server
		rc = write(sd, &sizeOfFilename, sizeof(sizeOfFilename));
		if (rc < 0)
			perror ("sendto");
		sizeOfFilename = ntohl(sizeOfFilename);
		//send the name of the file
		rc = write(sd, file, strlen(file));
		printf("the sizSe of filename is %d bytes, the sending filename is %s.\n",  sizeOfFilename,file);
		strcpy(inputFilename, file);
		//open the file by typing the name
		if ((inputFile = fopen(inputFilename, "rb")) == NULL) {
			printf("Error opening the input file '%s'\n", inputFilename);
			exit(1);
		}
		totalBytes = getFileLength(inputFile);
		rc = write(sd, &totalBytes, sizeof(totalBytes));

		numberOfBytes = fread(buffer, 1, BUFFSIZE, inputFile);
    	while (numberOfBytes > 0) {
        totalReadByte += numberOfBytes;
		rc = write(sd, buffer, numberOfBytes);
		if (rc <=0) {
                perror("write file bytes");
                exit(1);
            }
		numberOfBytes = fread(buffer, 1, BUFFSIZE, inputFile);
    }
		fclose(inputFile);
		printf("The size of the file is %d bytes, \n the size of the file is %d by reading each line.\n", totalBytes, totalReadByte);
		rc = read(sd, &receiveBytes, sizeof(int));
		//receive the file by ACK.
		printf("Received %d bytes of the file by ACK.\n", ntohl(receiveBytes));
		printf("What is the file you'd like to send?  ");
    	scanf("%s", file);

	}
    
	

	return 0 ;
}



